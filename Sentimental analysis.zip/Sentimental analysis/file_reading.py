import os
import nltk
from sentimental import remove_noice as rn
from sentimental import pos
import csv

ORIGINAL_DATA_PATA = "------------------"


def listToString(tokens_list):
    str1 = ' '
    return (str1.join(tokens_list))


neg_tokens_list = []
pos_tokens_list = []
words = []

train_reviews = open("train_reviews.csv", 'w', newline='', encoding='utf-8')
train_writer = csv.writer(train_reviews)
test_review = open("test_reviews.csv", 'w', newline='', encoding='utf-8')
test_writer = csv.writer(test_review)
train_writer.writerow(['Content', 'Label'])
test_writer.writerow(['Content', 'Label'])
for dir in os.listdir(ORIGINAL_DATA_PATA):
    count = 0
    for file in os.listdir(ORIGINAL_DATA_PATA + "//" + dir):
        f = open(ORIGINAL_DATA_PATA + "//" + dir + "//" + file)
        for line in f:
            new_list = []
            words = nltk.word_tokenize(line)
        updatedlist = rn.remove_punt(words)
        updatedlist1 = rn.remove_num(updatedlist)
        updatedlist2 = rn.remove_stopwords(updatedlist1)
        updatedlist3 = rn.remove_single_alphabets(updatedlist2)
        updatedlist0 = pos.pos_tagging(updatedlist3)
        updatedlist00 = pos.stemming_lemmatizati(updatedlist0)
        if dir == "neg":
            count = count + 1
            review_string = listToString(updatedlist00)
            if count < 326:
                train_writer.writerow([review_string, "neg"])
            else:
                test_writer.writerow([review_string, "neg"])

        else:
            count = count + 1
            review_string = listToString(updatedlist00)
            if count < 326:
                train_writer.writerow([review_string, "pos"])
            else:
                test_writer.writerow([review_string, "pos"])
